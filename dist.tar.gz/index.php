<?php
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
$trimmed = trim($uri, '/');
$dir = __DIR__ . '/' . $trimmed;

if (!empty($trimmed) && file_exists($dir . '/index.html')) {
    include $dir . '/index.html';
    exit;
}
if (!empty($trimmed) && file_exists(__DIR__ . '/' . $trimmed . '.html')) {
    include __DIR__ . '/' . $trimmed . '.html';
    exit;
}
if (!empty($trimmed) && file_exists(__DIR__ . '/' . $trimmed) && !is_dir(__DIR__ . '/' . $trimmed)) {
    return false;
}
include __DIR__ . '/index.html';
